from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def index(request):
    print("hi")
    return HttpResponse("hello everyone")

def show(request):
    print("kahfg")
    return render(request,"templates/login.html")