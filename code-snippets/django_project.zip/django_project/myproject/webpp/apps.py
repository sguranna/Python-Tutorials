from django.apps import AppConfig


class WebppConfig(AppConfig):
    name = 'webpp'
